/*!
 * ${copyright}
 */

sap.ui.define([], function() {
	"use strict";

	if (!window.Promise) {
		sap.ui.requireSync("sap/ui/thirdparty/es6-promise");
	}

});
